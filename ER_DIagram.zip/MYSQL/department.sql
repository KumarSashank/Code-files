-- Active: 1665341479744@@127.0.0.1@3306@srmap

CREATE TABLE
    department (
        Department_ID int,
        DEPARTMENT_Name VARCHAR(50),
        Building VARCHAR(50),
        Budget INT,
        PRIMARY KEY (Department_ID)
    );